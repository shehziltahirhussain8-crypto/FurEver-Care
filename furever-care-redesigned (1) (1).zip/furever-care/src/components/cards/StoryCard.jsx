import { Quote } from "lucide-react";
import "./Cards.css";

export default function StoryCard({ story }) {
  return (
    <article className="card media-card">
      <div className="media-card__image-wrap" style={{ aspectRatio: "16/11" }}>
        <img src={story.image} alt={story.petName} loading="lazy" />
      </div>
      <div className="media-card__body">
        <h3 className="media-card__title">{story.petName}</h3>
        <p className="media-card__desc">{story.story}</p>
        <blockquote style={{ margin: 0, padding: "10px 0 0", borderTop: "1px solid var(--color-bg-alt)", fontStyle: "italic", color: "var(--color-text-soft)", fontSize: "0.9rem", display: "flex", gap: 8 }}>
          <Quote size={16} color="var(--color-accent)" style={{ flexShrink: 0, marginTop: 2 }} />
          {story.testimonial}
        </blockquote>
        <span className="badge badge--terracotta" style={{ alignSelf: "flex-start" }}>
          Adopted {new Date(story.adoptionDate).toLocaleDateString(undefined, { month: "long", year: "numeric" })}
        </span>
      </div>
    </article>
  );
}
