import { CalendarDays, MapPin } from "lucide-react";

export default function EventCard({ event }) {
  const date = new Date(event.date);
  return (
    <div className="card flex gap-3" style={{ padding: "var(--space-4)", alignItems: "flex-start" }}>
      <div style={{ textAlign: "center", background: "var(--color-bg-alt)", borderRadius: "var(--radius-sm)", padding: "10px 14px", flexShrink: 0 }}>
        <div style={{ fontFamily: "var(--font-heading)", fontSize: "1.3rem", fontWeight: 700, color: "var(--color-accent-dark)" }}>
          {date.getDate()}
        </div>
        <div style={{ fontSize: "0.75rem", textTransform: "uppercase", color: "var(--color-text-soft)", fontWeight: 700 }}>
          {date.toLocaleDateString(undefined, { month: "short" })}
        </div>
      </div>
      <div>
        <span className="badge">{event.type}</span>
        <h3 className="media-card__title" style={{ marginTop: 6 }}>{event.title}</h3>
        <p className="media-card__desc">{event.description}</p>
        <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.82rem", color: "var(--color-text-soft)" }}>
          <MapPin size={14} /> {event.location}
        </span>
      </div>
    </div>
  );
}
