import { Phone, BadgeCheck } from "lucide-react";

export default function VetCard({ vet }) {
  return (
    <div className="card" style={{ padding: "var(--space-4)", textAlign: "center" }}>
      <img
        src={vet.image}
        alt={vet.name}
        loading="lazy"
        style={{ width: 96, height: 96, borderRadius: "50%", objectFit: "cover", margin: "0 auto var(--space-3)", border: "3px solid var(--color-secondary)" }}
      />
      <h3 className="media-card__title">{vet.name}</h3>
      <p style={{ color: "var(--color-accent-dark)", fontWeight: 600, fontSize: "0.9rem", marginBottom: 4 }}>{vet.specialization}</p>
      <p className="media-card__desc" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
        <BadgeCheck size={15} /> {vet.experience} experience
      </p>
      <p style={{ fontSize: "0.82rem", color: "var(--color-text-soft)", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
        <Phone size={13} /> {vet.contact}
      </p>
    </div>
  );
}
