import { Play, Clock } from "lucide-react";
import "./Cards.css";

export default function VideoCard({ video, onPlay }) {
  return (
    <article className="card media-card">
      <div className="media-card__image-wrap">
        <img src={video.thumbnail} alt={video.title} loading="lazy" />
        <button className="play-btn" onClick={() => onPlay?.(video)} aria-label={`Play ${video.title}`}>
          <span><Play size={22} fill="currentColor" /></span>
        </button>
      </div>
      <div className="media-card__body">
        <span className="badge">{video.category}</span>
        <h3 className="media-card__title">{video.title}</h3>
        <p className="media-card__desc">{video.description}</p>
        <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.82rem", color: "var(--color-text-soft)" }}>
          <Clock size={14} /> {video.duration}
        </span>
      </div>
    </article>
  );
}
