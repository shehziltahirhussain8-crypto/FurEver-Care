import { useState } from "react";
import { PlayCircle, ChevronDown } from "lucide-react";
import "./Cards.css";

const LEVEL_COLOR = { Beginner: "badge", Intermediate: "badge badge--terracotta", Advanced: "badge badge--danger" };

export default function TrainingCard({ item }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="card" style={{ padding: "var(--space-4)" }}>
      <div className="flex justify-between items-center gap-2">
        <span className={LEVEL_COLOR[item.difficulty] || "badge"}>{item.difficulty}</span>
        <PlayCircle size={20} color="var(--color-accent)" />
      </div>
      <h3 className="media-card__title mt-4">{item.title}</h3>
      <p className="media-card__desc">{item.description}</p>
      <button
        className="btn btn-ghost btn-sm btn-block"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
      >
        {open ? "Hide steps" : "Show steps"}
        <ChevronDown size={16} style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
      </button>
      {open && (
        <ol style={{ marginTop: 12, paddingLeft: 20, color: "var(--color-text-soft)", fontSize: "0.88rem", lineHeight: 1.8 }}>
          {item.steps.map((step, i) => <li key={i}>{step}</li>)}
        </ol>
      )}
    </div>
  );
}
