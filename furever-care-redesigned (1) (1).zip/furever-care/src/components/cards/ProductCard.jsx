import "./Cards.css";

export default function ProductCard({ product }) {
  return (
    <article className="card media-card">
      <div className="media-card__image-wrap">
        <img src={product.image} alt={product.name} loading="lazy" />
      </div>
      <div className="media-card__body">
        <span className="badge badge--terracotta">{product.category}</span>
        <h3 className="media-card__title">{product.name}</h3>
        <p className="media-card__desc">{product.description}</p>
        <div className="media-card__footer">
          <span className="media-card__price">${product.price.toFixed(2)}</span>
          <button className="btn btn-secondary btn-sm" title="Non-functional preview action">
            Buy Now
          </button>
        </div>
      </div>
    </article>
  );
}
