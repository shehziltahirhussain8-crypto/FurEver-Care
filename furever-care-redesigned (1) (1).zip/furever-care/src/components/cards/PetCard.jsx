import { PawPrint, MapPin } from "lucide-react";
import "./Cards.css";

export default function PetCard({ pet }) {
  return (
    <article className="card media-card">
      <div className="media-card__image-wrap">
        <img src={pet.image} alt={`${pet.name}, a ${pet.breed}`} loading="lazy" />
        <span className="badge" style={{ position: "absolute", top: 12, left: 12 }}>{pet.type}</span>
      </div>
      <div className="media-card__body">
        <h3 className="media-card__title">{pet.name}</h3>
        <p className="media-card__desc">{pet.description}</p>
        <div className="tag-row">
          <span className="badge badge--terracotta">{pet.breed}</span>
          <span className="badge badge--terracotta">{pet.age} yr</span>
        </div>
        <div className="media-card__footer">
          <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "0.82rem", color: "var(--color-text-soft)" }}>
            <MapPin size={14} /> {pet.location}
          </span>
          <button className="btn btn-primary btn-sm">
            <PawPrint size={14} /> Meet Me
          </button>
        </div>
      </div>
    </article>
  );
}
