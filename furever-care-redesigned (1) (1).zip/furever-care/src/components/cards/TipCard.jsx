import * as Icons from "lucide-react";
import "./Cards.css";

export default function TipCard({ tip }) {
  const Icon = Icons[tip.icon] || Icons.HeartPulse;
  return (
    <div className="card" style={{ padding: "var(--space-4)" }}>
      <div className="icon-tile"><Icon size={22} /></div>
      <h3 className="media-card__title">{tip.topic}</h3>
      <p className="media-card__desc">{tip.summary}</p>
      <details>
        <summary style={{ cursor: "pointer", fontWeight: 600, color: "var(--color-accent-dark)", fontSize: "0.85rem" }}>
          Learn more
        </summary>
        <p style={{ marginTop: 8, fontSize: "0.88rem" }}>{tip.detail}</p>
      </details>
    </div>
  );
}
