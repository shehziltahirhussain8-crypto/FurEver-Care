import { Outlet, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import Ticker from "../ui/Ticker";
import ScrollToTop from "../ui/ScrollToTop";
import EmergencyButton from "../ui/EmergencyButton";

export default function Layout() {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }, [location.pathname]);

  return (
    <>
      <Navbar />
      <Ticker />
      <main className="page" key={location.pathname}>
        <Outlet />
      </main>
      <Footer />
      <ScrollToTop />
      <EmergencyButton />
    </>
  );
}
