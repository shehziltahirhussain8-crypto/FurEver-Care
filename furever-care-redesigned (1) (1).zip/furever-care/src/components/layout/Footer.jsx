import { Link } from "react-router-dom";
import { PawPrint, Facebook, Instagram, Twitter, Phone, Mail, MapPin } from "lucide-react";
import "./Footer.css";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <div className="navbar__logo" style={{ color: "var(--color-white)" }}>
            <PawPrint size={24} />
            <span>FurEver <em>Care</em></span>
          </div>
          <p>They deserve forever love.</p>
          <div className="footer__social">
            <a href="#" aria-label="Facebook"><Facebook size={18} /></a>
            <a href="#" aria-label="Instagram"><Instagram size={18} /></a>
            <a href="#" aria-label="Twitter"><Twitter size={18} /></a>
          </div>
        </div>

        <div className="footer__col">
          <h4>Quick Links</h4>
          <Link to="/about">About Us</Link>
          <Link to="/products">Products</Link>
          <Link to="/adoption">Adoption</Link>
          <Link to="/contact">Contact</Link>
        </div>

        <div className="footer__col">
          <h4>Pet Care</h4>
          <Link to="/feeding-guide">Feeding Guide</Link>
          <Link to="/grooming">Grooming Videos</Link>
          <Link to="/health-tips">Health Tips</Link>
          <Link to="/training">Training Tips</Link>
        </div>

        <div className="footer__col">
          <h4>Emergency Help</h4>
          <Link to="/emergency" className="footer__emergency">24/7 Emergency Help</Link>
          <span><Phone size={14} /> (555) 011-2288</span>
          <span><Mail size={14} /> care@fureverclinic.com</span>
          <span><MapPin size={14} /> 145 Meadow Lane, Willow City</span>
        </div>
      </div>

      <div className="footer__bottom container">
        <span>© {year} FurEver Care. All rights reserved.</span>
        <span>Made with warmth for pets and the people who love them.</span>
      </div>
    </footer>
  );
}
