import { useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { PawPrint, Menu, X, User } from "lucide-react";
import { useUser } from "../../context/UserContext";
import "./Navbar.css";

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/pet-owner", label: "Pet Care" },
  { to: "/products", label: "Products" },
  { to: "/veterinarian", label: "Veterinarians" },
  { to: "/adoption", label: "Adoption" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { userType, firstName } = useUser();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <header className={`navbar ${scrolled ? "navbar--scrolled" : ""}`}>
      <div className="container navbar__inner">
        <NavLink to="/" className="navbar__logo" onClick={() => setOpen(false)}>
          <PawPrint size={26} strokeWidth={2.4} />
          <span>
            FurEver <em>Care</em>
          </span>
        </NavLink>

        <nav className="navbar__links" aria-label="Primary">
          {LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => "navbar__link" + (isActive ? " is-active" : "")}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="navbar__actions">
          {userType ? (
            <button className="navbar__user" onClick={() => navigate(`/${userType === "owner" ? "pet-owner" : userType === "vet" ? "veterinarian" : "shelter"}`)}>
              <User size={16} />
              <span>Hi, {firstName || "friend"}</span>
            </button>
          ) : (
            <NavLink to="/#get-started" className="btn btn-primary btn-sm">
              Get Started
            </NavLink>
          )}
          <button
            className="navbar__burger"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <div className={`navbar__mobile ${open ? "is-open" : ""}`}>
        <nav aria-label="Mobile">
          {LINKS.map((link) => (
            <NavLink key={link.to} to={link.to} onClick={() => setOpen(false)} className="navbar__mobile-link">
              {link.label}
            </NavLink>
          ))}
          {!userType && (
            <NavLink to="/#get-started" onClick={() => setOpen(false)} className="btn btn-primary btn-block mt-4">
              Get Started
            </NavLink>
          )}
        </nav>
      </div>
    </header>
  );
}
