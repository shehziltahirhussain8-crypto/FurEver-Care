import { Link } from "react-router-dom";
import { AlertTriangle } from "lucide-react";
import "./EmergencyButton.css";

export default function EmergencyButton() {
  return (
    <Link to="/emergency" className="emergency-fab" aria-label="Emergency Help">
      <AlertTriangle size={18} />
      <span>Emergency Help</span>
    </Link>
  );
}
