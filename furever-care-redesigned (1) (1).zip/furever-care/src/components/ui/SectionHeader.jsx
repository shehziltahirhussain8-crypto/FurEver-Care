export default function SectionHeader({ eyebrow, title, description, align = "center" }) {
  return (
    <div className="section-header" style={{ textAlign: align, margin: align === "left" ? "0 0 var(--space-6)" : undefined }}>
      {eyebrow && <span className="eyebrow" style={{ justifyContent: align === "left" ? "flex-start" : "center" }}>{eyebrow}</span>}
      <h2>{title}</h2>
      {description && <p>{description}</p>}
    </div>
  );
}
