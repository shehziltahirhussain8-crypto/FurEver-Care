import { useClock } from "../../hooks/useClock";
import { useGeolocation } from "../../hooks/useGeolocation";
import { PawPrint } from "lucide-react";
import "./Ticker.css";

const REMINDERS = [
  "Reminder: annual wellness checkups catch problems early.",
  "Tip: fresh water bowls should be refreshed daily.",
  "Did you know? A tired dog is a well-behaved dog — daily walks matter.",
  "Reminder: keep flea & tick prevention up to date this season.",
];

export default function Ticker() {
  const now = useClock();
  const geo = useGeolocation();

  const timeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });

  let locationStr = "Location unavailable";
  if (geo.status === "loading") locationStr = "Locating you...";
  if (geo.status === "granted" && geo.coords) {
    locationStr = `Lat ${geo.coords.latitude.toFixed(2)}, Lng ${geo.coords.longitude.toFixed(2)}`;
  }
  if (geo.status === "denied") locationStr = "Location access declined";
  if (geo.status === "unsupported") locationStr = "Geolocation not supported";

  const items = [
    `${dateStr} · ${timeStr}`,
    locationStr,
    ...REMINDERS,
  ];

  return (
    <div className="ticker" role="marquee" aria-label="Live updates">
      <div className="ticker__track">
        {[...items, ...items].map((item, i) => (
          <span className="ticker__item" key={i}>
            <PawPrint size={12} /> {item}
          </span>
        ))}
      </div>
    </div>
  );
}
