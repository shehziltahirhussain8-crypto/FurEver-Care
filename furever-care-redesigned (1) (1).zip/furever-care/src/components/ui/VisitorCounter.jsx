import { Users } from "lucide-react";
import { useCountUp } from "../../hooks/useCountUp";
import "./VisitorCounter.css";

export default function VisitorCounter({ target = 12458 }) {
  const [ref, value] = useCountUp(target);
  return (
    <div className="visitor-counter" ref={ref}>
      <div className="visitor-counter__icon"><Users size={22} /></div>
      <div>
        <div className="visitor-counter__number">{value.toLocaleString()}</div>
        <div className="visitor-counter__label">Pet Lovers Joined</div>
      </div>
    </div>
  );
}
